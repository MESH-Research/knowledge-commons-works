# Run with `pipenv run invenio shell change_owner.py`

import click,csv

from invenio_utilities_tuw.utils import get_identity_for_user, get_record_service, get_user_by_identifier
from invenio_utilities_tuw.cli.utils import set_record_owners
from pprint import pprint

@click.group()
def cli():
    pass


@click.command()
@click.argument('user_email', type=str)
def get_user_id(user_email):
    v = get_user_by_identifier(user_email)
    pprint(f'success: user id is {v.id}')
    return(v.id)

@click.command('change_owner')
@click.argument('recid', type=str)
@click.argument('owner', type=int)
@click.argument('user', type=int)
def change_owner(recid, owner, user):
    u = get_identity_for_user(user)
    service = get_record_service()
    record = service.read(id_=recid, identity=u)._record
    all_owners = [get_user_by_identifier(owner)]
    set_record_owners(record, all_owners)
    if service.indexer:
        service.indexer.index(record)
    pprint(service.read(id_=recid, identity=u)._record)
    return(service.read(id_=recid, identity=u)._record)


@click.command('change_owners')
@click.argument('owner_file', type=click.File('r'))
def change_owners(owner_file):
    reader = csv.reader(owner_file)
    for line in reader:
        print(line[0])
        change_owner(line[0],int(line[1]),2)
        exit()

cli.add_command(change_owner)
cli.add_command(change_owners)
cli.add_command(get_user_id)

if __name__=="__main__":
    cli()