# CORE Migrate

Migration scripts to convert and move legacy Humanities Commons CORE deposits to the Knowledge Commons Repository InvenioRDM instance.

## Copyright

Copyright 2023 MESH Research. Released under the MIT license.
